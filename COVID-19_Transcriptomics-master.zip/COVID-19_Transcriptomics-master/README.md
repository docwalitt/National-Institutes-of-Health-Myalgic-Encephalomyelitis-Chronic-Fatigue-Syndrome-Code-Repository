# COVID-19_Transcriptomics
 Network Analysis and Transcriptome Profiling Identify Autophagic and Mitochondrial Dysfunctionsin SARS-CoV-2 Infection 

<p align="center">
  <img src="Figure 1.png" width="1000"  title="Workflow Schema">
</p>

